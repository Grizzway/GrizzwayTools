export default [
    // Alert
    () => {
      alert('You are using Grizzway Tools, Chao Garden theme');
    },
  

    // Logo Glow
    () => {
        let imgs = [];
        let styleEl = null;
        let observer = null;
      
        const selectors = [
          '.top-bar_logo__XL0_C img.maejok-logo_hover',
          '.top-bar_logo__XL0_C img.maejok-logo_hide',
          '.top-bar_logo__XL0_C img.top-bar_desktop__pjX2g'
        ];
      
        const applyGlow = () => {
          imgs = selectors
            .map(sel => Array.from(document.querySelectorAll(sel)))
            .flat()
            .filter(Boolean);
      
          if (!imgs.length) return false;
      
          imgs.forEach(img => img.classList.add('grizz-glow-img'));
      
          styleEl = document.createElement('style');
          styleEl.id = 'grizz-glow-style';
          styleEl.textContent = `
            @keyframes grizzGlow {
              from { filter: drop-shadow(0 0 0px red); }
              to   { filter: drop-shadow(0 0 10px red); }
            }
      
            .grizz-glow-img {
              animation: grizzGlow 1.6s infinite alternate !important;
              will-change: filter;
            }
          `;
          document.head.appendChild(styleEl);
      
          return true;
        };
      
        if (!applyGlow()) {
          observer = new MutationObserver(() => {
            if (applyGlow()) observer.disconnect();
          });
      
          observer.observe(document.body, {
            childList: true,
            subtree: true,
          });
        }
      
        return () => {
          imgs.forEach(img => img.classList.remove('grizz-glow-img'));
          if (styleEl && styleEl.parentNode) styleEl.remove();
          if (observer) observer.disconnect();
        };
      }
  ];
  